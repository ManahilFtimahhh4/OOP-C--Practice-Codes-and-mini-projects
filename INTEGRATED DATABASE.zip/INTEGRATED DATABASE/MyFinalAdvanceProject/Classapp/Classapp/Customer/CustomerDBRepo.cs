﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerDBRepo
    {

        public readonly string file = "customers.txt";

        public void SaveAlldataintofile(CustomerModel customer)
        {
            using (StreamWriter data = new StreamWriter(file, true))
            {
                data.WriteLine(customer.ToString());
            }
        }

        public void savedata(List<CustomerModel> customers)
        {
            File.WriteAllText(file, "");
            foreach (var customer in customers)
            {
                SaveAlldataintofile(customer);
            }


        }

        public List<CustomerModel> getCustomer()
        {
            List<CustomerModel> customers = new List<CustomerModel>();

            using (StreamReader data = new StreamReader(file))
            {
                string record = "";

                while ((record = data.ReadLine()) != null)
                {
                    string[] parts = record.Split(',');

                    string name = parts[0];
                    string phoonenumber = parts[1];
                    int age = int.Parse(parts[2]);
                    string address = parts[3];

                    CustomerModel store = new CustomerModel(name, phoonenumber, age, address);
                    customers.Add(store);

                }
                return customers;

            }

        }

        public bool Create(CustomerModel customer)
        {
            using(SqlConnection conn = new SqlConnection(util.DbConnection()))
            {
                
                string query = "INSERT INTO Customer (name,phonenumber,age,address) VALUES (@Name,@PhoneNumber,@Age,@Address)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", customer.getname());
                cmd.Parameters.AddWithValue("@PhoneNumber", customer.getnumber());
                cmd.Parameters.AddWithValue("@Age", customer.getage());
                cmd.Parameters.AddWithValue("@Address", customer.getaddress());

                conn.Open();
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true;  }
                
               else { return false; }
               
            }
            
        }

        public List<CustomerModel> GetAll()
        {
            List<CustomerModel> allcustomer = new List<CustomerModel>();
            using(SqlConnection con = new SqlConnection(util.DbConnection()))
            {
                con.Open();
                string query = "select*from customer";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    int id = Convert.ToInt32(reader["Id"]);
                    string name = Convert.ToString(reader["Name"]);
                    int age = Convert.ToInt32(reader["age"]);
                    string address = Convert.ToString(reader["age"]);
                    string phonenumber = Convert.ToString(reader["phonenumber"]);
                    CustomerModel cust = new CustomerModel(id, name, phonenumber, age, address);
                    allcustomer.Add(cust);
                }

                reader.Close();
       
            }
            return allcustomer;
        }

        public bool delete(int Id)
        {
                       using(SqlConnection con = new SqlConnection(util.DbConnection()))
            {
                con.Open();
                string query = "delete from customer where Id=@Id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Id", Id);
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true; }
                else { return false; }
            }
        }

        public bool Update(CustomerModel customer)
        {
            using (SqlConnection conn = new SqlConnection(util.DbConnection()))
            {

                string query = "UPDATE Customer SET name=@name,phonenumber=@phonenumber,age=@age,address=@address WHERE Id=@Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                
                cmd.Parameters.AddWithValue("@Name", customer.getname());
                cmd.Parameters.AddWithValue("@PhoneNumber", customer.getnumber());
                cmd.Parameters.AddWithValue("@Age", customer.getage());
                cmd.Parameters.AddWithValue("@Address", customer.getaddress());
                cmd.Parameters.AddWithValue("@Id", customer.getId());
                conn.Open();
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true; }

                else { return false; }

            }

        }




        //.....................................................
    }

}
