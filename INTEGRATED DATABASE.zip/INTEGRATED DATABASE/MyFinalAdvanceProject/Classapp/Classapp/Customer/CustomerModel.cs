﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerModel
    {
        private int Id;

        private string name;
        private string phonenumber;
        private int age;
        private string address;
       

        public CustomerModel( string name, string phonenumber, int age, string address)
        {
            
            this.name = name;
            this.phonenumber = phonenumber;
            this.age = age;
            this.address = address;
        }

        public CustomerModel(int Id , string name , string phonenumber , int age , string  address) 
        {
            this.Id = Id;
            this.name = name;
            this.phonenumber= phonenumber;
            this.age = age;
            this.address = address;
        }

        public override string ToString()
        {
            return $"{Id},{name},{phonenumber},{age},{address}";
        }

        public void setname(string name)
        {
            this.name = name;
        }
        public string getname()
        {
            return this.name;
        }
        public void setphonenumber(string phonenumber)
        {
            this.phonenumber = phonenumber;
        }
        public string getnumber()
        {
            return this.phonenumber;
        }
        public void setage(int age)
        {
            this.age = age;
        }
        public int getage()
        {
            return this.age;
        }
        public void setaddress(string address)
        {
            this.address = address;
        }
        public string getaddress()
        {
            return this.address;
        }

        public void setId(int Id)
        {
            this.Id = Id;
        }

        public int getId()
        {
            return this.Id;
        }

    }
}
