﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerService
    {

        private CustomerDBRepo _repo;
        private CustomerDBRepo _repoDb = new CustomerDBRepo();

        public CustomerService()
        {
            _repo = new CustomerDBRepo();
        }
        public void AddCustomer(CustomerModel customers)
        {
            _repoDb.Create(customers);
        }
        public List<CustomerModel> Getalldata()
        {
            return _repoDb.GetAll();
        }

        public CustomerModel searchbyname(string name)
        {
            foreach (var customer in _repo.getCustomer())
            {
                if (customer.getname() == name)
                {

                    return customer;
                }
            }

            return null;
        }

        public bool UpdateCustomer(CustomerModel customer)
        {
            return _repoDb.Update(customer);
        }

        public bool deletebyId(int Id)
        {
           

            return _repo.delete(Id);

        }

        public CustomerModel SearchByName(string name)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getname() == name)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }

        public CustomerModel SearchByPhoneNumber(string phoneNumber)
        {
            foreach(CustomerModel customer in _repo.getCustomer())
            {
                if(customer.getnumber() == phoneNumber)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }


        public CustomerModel SearchByAddress(string address)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getaddress() == address)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }

        public CustomerModel SearchByAge(int  age)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getage() == age)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }
        public List<CustomerModel> SearchByfirstChar(char firstChar)
                
        {
            List<CustomerModel> matched = new List<CustomerModel>();
            foreach ( CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getname()[0] == firstChar)
                {
                    Console.WriteLine(customer);
                    matched.Add(customer);
                }
            }
           

            if(matched.Count == 0)
            {
                Console.WriteLine("no such user found ..!");
            }
            Console.ReadLine();
            return matched;

        }



    }
}
