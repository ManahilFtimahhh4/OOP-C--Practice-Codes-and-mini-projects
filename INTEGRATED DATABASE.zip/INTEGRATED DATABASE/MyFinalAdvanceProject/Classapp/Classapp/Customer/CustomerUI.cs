﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerUI
    {
        private CustomerService customerService;
        public CustomerUI()
        {
            customerService = new CustomerService();
        }

        public void CustomerDriven()
        {

            while (true)
            {
                Console.Clear();
                string option = CustomerMenu();
                if (option == "1")
                {
                    CustomerModel data = Takeinput();
                    customerService.AddCustomer(data);
                    Console.ReadKey();

                }
                else if (option == "2")
                {
                    if (customerService.UpdateCustomer(Takeinput()))
                    {
                        Console.WriteLine("Updated successfully...");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Customer not found");
                        Console.ReadKey();
                    }
                }
                else if (option == "3")
                {
                    deleteCustomer();
                    Console.ReadKey();
                }
                else if (option == "4")
                {
                    searchCustomer();
                    Console.ReadKey();
                }
                else if (option == "5")
                {
                    displayall();
                    Console.ReadKey();


                }
                else if (option == "6")
                {

                    while (true)
                    {
                        Console.Clear();

                        string opt = AdvanceMenu();

                        if (opt == "1") { SearchByName(); }
                        else if (opt == "2") { SearchByFirstChar(); }
                        else if (opt == "3") { SearchByphoneNumber(); }
                        else if (opt == "4") { SearchByAddress(); }
                        else if (opt == "5") { break; }
                        else if (opt == "6") { SearchByAge(); }

                        else
                        {
                            Console.WriteLine("you entered wrong option");
                        }



                    }
                }



                else if (option == "7")
                {
                    break;



                }
                else
                {
                    Console.WriteLine("you choose wrong option");
                }
            }
        }
        public string CustomerMenu()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=======================================");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("==       Customer Managemanent       ==");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("=======================================");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("1- Add");
            Console.WriteLine("2- Update");
            Console.WriteLine("3- Delete");
            Console.WriteLine("4- search");
            Console.WriteLine("5- View all");
            Console.WriteLine("6-Avance options");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("7- back");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("enter the option");
            string choice = Console.ReadLine();
            return choice;


        }
        public CustomerModel Takeinput()
        {
            Console.WriteLine("Enter the Id");
            int Id = int.Parse(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Phone number");
            string phonenumber = Console.ReadLine();
            Console.WriteLine("Enter the age");
            int aage = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the address");
            string address = Console.ReadLine();

            CustomerModel cust = new CustomerModel(  Id, name, phonenumber, aage, address);

            Console.WriteLine("Customer added successfullyy");
            return cust;
        }
      







        public void displayall()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            List<CustomerModel> customers = customerService.Getalldata();
            foreach (var c in customers)
            {
                Console.WriteLine(c.ToString());
            }
            Console.ReadKey();
        }
    
        public void deleteCustomer()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Enter customer id");
            int Id  =int.Parse(Console.ReadLine());



            if (customerService.deletebyId(Id) == true)
            {
                Console.WriteLine("data deleted successfully");

            }
            else
            {
                Console.WriteLine("Enter correct id of the person you want to delete");
            }
        }
        public void searchCustomer()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();

            CustomerModel customer = customerService.searchbyname(name);

            if (customer != null)
            {
                Console.WriteLine(customer.ToString());
                Console.WriteLine("customer found");

            }
            else
            {
                Console.WriteLine("Customer not found");
            }


        }

        public string AdvanceMenu()
        {
    
            Console.WriteLine("1-Search Customer by name");
            Console.WriteLine("2-Search Customer by First character");
            Console.WriteLine("3-Search Customer by Phone Number");
            Console.WriteLine("4-Search Customer by Address");
            Console.WriteLine("5-break");
            Console.WriteLine("6-Search Customer by Age");

            Console.WriteLine("Enter your option :");

            string opti=Console.ReadLine();



            return opti;
        }

        public void SearchByName()
        {
            Console.WriteLine("Enter name");
            String name = Console.ReadLine();

           customerService.SearchByName(name);

        }

        public void SearchByphoneNumber()
        {
            Console.WriteLine("Enter nphone number");
            String  phoneNumber= Console.ReadLine();

            customerService.SearchByPhoneNumber(phoneNumber);


        }

        public void SearchByAddress()
        {
            Console.WriteLine("Enter adress");
            String address = Console.ReadLine();

            customerService.SearchByAddress(address);


        }

        public void SearchByAge()
        {
            Console.WriteLine("Enter Age");
            int age = int.Parse(Console.ReadLine());

            customerService.SearchByAge(age);

        }


        public void SearchByFirstChar()
        {
            Console.WriteLine("Enter character");
            char firstchar = char.Parse(Console.ReadLine());

            customerService.SearchByfirstChar(firstchar);

        }


      






    }
}
