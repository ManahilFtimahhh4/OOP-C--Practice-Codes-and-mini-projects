﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Product
{
    internal class ProductModel
    {
        public int Idp;
        private string name;
        private string description;
        private float purchasePrice;
        private float salePrice;
        private float discount;
        
        public ProductModel()
        {

        }
        public ProductModel(string name, string desc, float pprice, float salePrice, float discount)
        {
            this.name = name;
            this.description = desc;
            this.purchasePrice = pprice;
            this.salePrice = salePrice;
            this.discount = discount;
        }


        public ProductModel( int Idp,string name, string desc, float pprice, float salePrice, float discount)
        {
            this.Idp = Idp;
            this.name = name;
            this.description = desc;
            this.purchasePrice = pprice;
            this.salePrice = salePrice;
            this.discount = discount;
        }







        public void SetName(string name) {
            this.name = name;
        }
        public string GetName() { return this.name; }   

        public void SetDescription(string  description) { this.description = description; }
        public string GetDescription() { return this.description; }
        
        public void SetPurchasePrice(float price) { this.purchasePrice = price; }
        public float GetPurchasePrice() { return this.purchasePrice; }
        public void SetSalePrice(float price) {this.salePrice = price; }
        public float GetSalePrice() {  return this.salePrice - discount; }

        public float GetDiscount() { return this.discount; }

        public void setIdp(int Idp)
        {
            this.Idp = Idp;
        }

        public int getIdp()
        {
            return this.Idp;
        }



        public override string ToString()
        {
            return $"{Idp},{name},{description},{purchasePrice},{salePrice},{discount}";
        }


    }
}
