﻿using Classapp.Customer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Product
{
    internal class ProductRepo
    {
        private readonly string file = "product.txt";
        public ProductRepo() { }

        public void SaveInFile(ProductModel product)
        {
            using (StreamWriter stream = new StreamWriter(file, true)) { 
                   stream.WriteLine(product.ToString());
            }

        }
        public void SaveAllDataIntoFile(List<ProductModel> products)
        {
            File.WriteAllText(file, string.Empty);
            foreach (ProductModel product in products) {
                SaveInFile(product);
            }
        }

      



        //   Ali,50,03055465464

        public List<ProductModel> GetProductsFromFile()
        {
            List<ProductModel> productsList = new List<ProductModel>();
            using (StreamReader stream = new StreamReader(file)) {

                string line = "";
                while((line = stream.ReadLine()) != null){

                    string[] parts = line.Split(',');
                    string productName = parts[0];
                    string desc = parts[1];
                    float purchasePrice = float.Parse(parts[2]);
                    float salePrice = float.Parse(parts[3]);
                    float discount = float.Parse(parts[4]);

                    ProductModel productModel = new ProductModel(productName, desc, purchasePrice, salePrice, discount);
                    productsList.Add(productModel);

                }
            
            }

            return productsList;
        } 


        public List<bool> QuizDobaraQuestion()
        {
            List<bool> all = new List<bool>();
            for (int i = 0; i < 100000000; i++) { 
                all.Add(false);
            }
            return all;
        }


        public bool Create(ProductModel product)
        {
            using (SqlConnection conn = new SqlConnection(util.DbConnection()))
            {

                string query = "INSERT INTO Product (Name,Description,SalePrice,PurchasePrice,Discount) VALUES (@Name,@Description,@SalePrice,@PurchasePrice,@Discount)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Name", product.GetName());
                cmd.Parameters.AddWithValue("@Description", product.GetDescription());
                cmd.Parameters.AddWithValue("@SalePrice", product.GetSalePrice());
                cmd.Parameters.AddWithValue("@PurchasePrice", product.GetPurchasePrice());
                cmd.Parameters.AddWithValue("@Discount", product.GetDiscount());

                conn.Open();
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true; }

                else { return false; }

            }

        }

        public List<ProductModel> GetAll()
        {
            List<ProductModel> allProduct = new List<ProductModel>();
            using (SqlConnection con = new SqlConnection(util.DbConnection()))
            {
                con.Open();
                string query = "select*from product";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int Idp = Convert.ToInt32(reader["Idp"]);
                    string Name = Convert.ToString(reader["Name"]);
                    string Description = Convert.ToString(reader["Description"]);
                    int PurchasePrice = Convert.ToInt32(reader["PurchasePrice"]);
                    int SalePrice= Convert.ToInt32(reader["salePrice"]);
                   int Discount= Convert.ToInt32(reader["Discount"]);
                    ProductModel prod = new ProductModel(Idp, Name,Description, PurchasePrice, SalePrice, Discount);
                    allProduct.Add(prod);
                }

                reader.Close();

            }
            return allProduct;
        }

        public bool delete(int Idp)
        {
            using (SqlConnection con = new SqlConnection(util.DbConnection()))
            {
                con.Open();
                string query = "delete from Product where Idp=@Idp";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@Idp", Idp);
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true; }
                else { return false; }
            }
        }

        public bool Update(ProductModel Product)
        {
            using (SqlConnection conn = new SqlConnection(util.DbConnection()))
            {

                string query = "UPDATE Product SET Name=@Name,Description=@Description,SalePrice=@SalePrice,PurchasePrice=@PurchasePrice , Discount=@Discount WHERE Idp=@Idp";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@Idp", Product.getIdp());
                cmd.Parameters.AddWithValue("@Name", Product.GetName());
                cmd.Parameters.AddWithValue("@Description", Product.GetDescription());
                cmd.Parameters.AddWithValue("@SalePrice", Product.GetSalePrice());
                cmd.Parameters.AddWithValue("@PurchasePrice", Product.GetPurchasePrice());
                cmd.Parameters.AddWithValue("@Discount", Product.GetDiscount());

                conn.Open();
                int effectrows = cmd.ExecuteNonQuery();
                if (effectrows > 0) { return true; }

                else { return false; }

            }

        }








    }
}