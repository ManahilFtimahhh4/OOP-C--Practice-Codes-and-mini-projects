﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Product
{
    internal class util
    {
        public static string DbConnection()
        {

            return "server =localhost;Database=POS2;Trusted_Connection=true";
        }
    }
}
