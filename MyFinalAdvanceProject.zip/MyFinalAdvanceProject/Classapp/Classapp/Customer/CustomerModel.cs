﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerModel
    {
        private string name;
        private string phonenumber;
        private int age;
        private string address;

        public CustomerModel(string name, string phonenumber, int age, string address)
        {
            this.name = name;
            this.phonenumber = phonenumber;
            this.age = age;
            this.address = address;
        }

        public override string ToString()
        {
            return $"{name},{phonenumber},{age},{address}";
        }

        public void setname(string name)
        {
            this.name = name;
        }
        public string getname()
        {
            return this.name;
        }
        public void setphonenumber(string phonenumber)
        {
            this.phonenumber = phonenumber;
        }
        public string getnumber()
        {
            return this.phonenumber;
        }
        public void setage(int age)
        {
            this.age = age;
        }
        public int getage()
        {
            return this.age;
        }
        public void setaddress(string address)
        {
            this.address = address;
        }
        public string getaddress()
        {
            return this.address;
        }
    }
}
