﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerRepo
    {

        public readonly string file = "customers.txt";

        public void SaveAlldataintofile(CustomerModel customer)
        {
            using (StreamWriter data = new StreamWriter(file, true))
            {
                data.WriteLine(customer.ToString());
            }
        }

        public void savedata(List<CustomerModel> customers)
        {
            File.WriteAllText(file, "");
            foreach (var customer in customers)
            {
                SaveAlldataintofile(customer);
            }


        }

        public List<CustomerModel> getCustomer()
        {
            List<CustomerModel> customers = new List<CustomerModel>();

            using (StreamReader data = new StreamReader(file))
            {
                string record = "";

                while ((record = data.ReadLine()) != null)
                {
                    string[] parts = record.Split(',');

                    string name = parts[0];
                    string phoonenumber = parts[1];
                    int age = int.Parse(parts[2]);
                    string address = parts[3];

                    CustomerModel store = new CustomerModel(name, phoonenumber, age, address);
                    customers.Add(store);

                }
                return customers;

            }

        }
    }

}
