﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Customer
{
    internal class CustomerService
    {

        private CustomerRepo _repo;

        public CustomerService()
        {
            _repo = new CustomerRepo();
        }
        public void AddCustomer(CustomerModel customers)
        {
            _repo.SaveAlldataintofile(customers);
        }
        public List<CustomerModel> Getalldata()
        {
            return _repo.getCustomer();
        }

        public CustomerModel searchbyname(string name)
        {
            foreach (var customer in _repo.getCustomer())
            {
                if (customer.getname() == name)
                {

                    return customer;
                }
            }

            return null;
        }

        public bool Updatebyname(string name, string newname, string phonenumber, int age, string address)
        {
            List<CustomerModel> customers = _repo.getCustomer();
            foreach (var customer in customers)
            {
                if (customer.getname() == name)
                {
                    customer.setname(newname);
                    customer.setphonenumber(phonenumber);
                    customer.setage(age);
                    customer.setaddress(address);
                    _repo.savedata(customers);
                    return true;
                }
            }
            return false;
        }

        public bool deletebyname(string name)
        {
            List<CustomerModel> customers = _repo.getCustomer();
            int count = 0;
            foreach (var customer in customers)
            {
                if (customer.getname() == name)
                {
                    customers.RemoveAt(count);

                    _repo.savedata(customers);
                    return true;
                }
                count++;
            }
            return false;



        }

        public CustomerModel SearchByName(string name)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getname() == name)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }

        public CustomerModel SearchByPhoneNumber(string phoneNumber)
        {
            foreach(CustomerModel customer in _repo.getCustomer())
            {
                if(customer.getnumber() == phoneNumber)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }


        public CustomerModel SearchByAddress(string address)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getaddress() == address)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }

        public CustomerModel SearchByAge(int  age)
        {
            foreach (CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getage() == age)
                {
                    Console.WriteLine(customer);
                    Console.ReadKey();
                    return customer;
                }
            }

            return null;
        }
        public List<CustomerModel> SearchByfirstChar(char firstChar)
                
        {
            List<CustomerModel> matched = new List<CustomerModel>();
            foreach ( CustomerModel customer in _repo.getCustomer())
            {
                if (customer.getname()[0] == firstChar)
                {
                    Console.WriteLine(customer);
                    matched.Add(customer);
                }
            }
           

            if(matched.Count == 0)
            {
                Console.WriteLine("no such user found ..!");
            }
            Console.ReadLine();
            return matched;

        }



    }
}
