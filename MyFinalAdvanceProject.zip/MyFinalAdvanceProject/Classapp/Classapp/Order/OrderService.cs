﻿using Classapp.Order;
using Classapp.Customer;
using Classapp.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Order
{
    internal class OrderService
    {
        private readonly OrderRepo _repo = new OrderRepo();


        public List<OrderModel> GetAllOrders()
        {
            return _repo.GetAllOrders();
        }


        public List<OrderModel> GetOrdersByCustomerName(string customerName)
        {
            List<OrderModel> allOrders = _repo.GetAllOrders();
            List<OrderModel> orders = new List<OrderModel>();
            foreach (OrderModel order in allOrders)
            {
                if (order.customername == customerName)
                {
                    orders.Add(order);
                }
            }
            return orders;
        }

        public bool SaveOrder(OrderModel order)
        {
            OrderRepo orderRepo = new OrderRepo();
            orderRepo.Save(order);
            Console.WriteLine("Order saved successfully!");
            return true;
        }

        public List<OrderModel> CheckNameAndCount(string name, int count)
        {
            List<OrderModel> allOrders = _repo.GetAllOrders();
            List<OrderModel> orderModels = new List<OrderModel>();
            foreach (OrderModel order in allOrders)
            {
                if (order.customername == name && count > 5)
                {
                    orderModels.Add(order);
                }
            }
            return orderModels;
        }


    }
}
