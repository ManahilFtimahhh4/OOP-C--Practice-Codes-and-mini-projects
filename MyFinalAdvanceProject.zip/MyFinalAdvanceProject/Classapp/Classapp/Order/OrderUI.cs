﻿using Classapp.Order;
using Classapp.Product;
using System;
using System.Collections.Generic;

namespace Classapp.Order
{
    internal class OrderUI
    {
        private readonly OrderService orderService = new OrderService();

        public void OrderDriver()
        {
            while (true)
            {
                string option = OrderMenu();
                Console.Clear();

                if (option == "1")
                {
                    PlaceNewOrder();
                    Console.ReadKey();
                }
                else if (option == "2")
                {
                    DisplayAllOrders();
                    Console.ReadKey();
                }
                else if (option == "3")
                {
                    SearchOrderByCustomer();
                    Console.ReadKey();
                }
                else if (option == "0")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Option!");
                    Console.ReadKey();
                }
            }
        }

        private string OrderMenu()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("                 ORDER MANAGEMENT                 ");
            Console.WriteLine("--------------------------------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1. Place New Order");
            Console.WriteLine("2. View All Orders");
            Console.WriteLine("3. Search Orders by Customer");
            Console.WriteLine("0. Go Back to Main Menu");
            Console.WriteLine("--------------------------------------------------");
            Console.Write("Enter Your Choice: ");
            return Console.ReadLine();
        }

        private void PlaceNewOrder()
        {
            Console.WriteLine("Enter Customer Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Contact:");
            string contact = Console.ReadLine();

            Console.WriteLine("Enter Address:");
            string address = Console.ReadLine();

            OrderModel order = new OrderModel(name, contact, address);

            Console.Write("How many items do you want to add? ");
            int totalItems = int.Parse(Console.ReadLine());

            for (int i = 0; i < totalItems; i++)
            {
                Console.WriteLine($"\nItem {i + 1}:");
                Console.Write("Enter Product Name: ");
                string product = Console.ReadLine();

                Console.Write("Enter Quantity: ");
                int quantity = int.Parse(Console.ReadLine());

                Console.Write("Enter Sale Price: ");
                int price = int.Parse(Console.ReadLine());

                OrderItem item = new OrderItem(product, quantity, price);
                order.AddOrder(item);
            }

            orderService.SaveOrder(order);
            Console.WriteLine(" Order Saved Successfully!");
        }

        private void DisplayAllOrders()
        {
            List<OrderModel> orders = orderService.GetAllOrders();

            if (orders.Count == 0)
            {
                Console.WriteLine("No orders found!");
                return;
            }

            foreach (var order in orders)
            {
                Console.WriteLine($"\nCustomer: {order.customername}");
                Console.WriteLine($"Contact: {order.contact}");
                Console.WriteLine($"Address: {order.address}");
                Console.WriteLine("Items:");

                foreach (var item in order.ordersList)
                {
                    Console.WriteLine($"  → Product: {item.product}, Qty: {item.quantity}, Price: {item.salePrice}, Total: {item.quantity * item.salePrice}");
                }
            }
        }

        private void SearchOrderByCustomer()
        {
            Console.Write("Enter Customer Name: ");
            string name = Console.ReadLine();

            List<OrderModel> foundOrders = orderService.GetOrdersByCustomerName(name);

            if (foundOrders.Count == 0)
            {
                Console.WriteLine("No orders found for this customer.");
                return;
            }

            foreach (var order in foundOrders)
            {
                Console.WriteLine($"\nCustomer: {order.customername}");
                Console.WriteLine($"Contact: {order.contact}");
                Console.WriteLine($"Address: {order.address}");
                Console.WriteLine("Items:");

                foreach (var item in order.ordersList)
                {
                    Console.WriteLine($"  → Product: {item.product}, Qty: {item.quantity}, Price: {item.salePrice}, Total: {item.quantity * item.salePrice}");
                }
            }
        }
    }
}
