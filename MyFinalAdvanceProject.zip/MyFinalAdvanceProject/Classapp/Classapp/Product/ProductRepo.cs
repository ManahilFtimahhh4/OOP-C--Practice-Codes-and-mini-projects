﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Product
{
    internal class ProductRepo
    {
        private readonly string file = "product.txt";
        public ProductRepo() { }

        public void SaveInFile(ProductModel product)
        {
            using (StreamWriter stream = new StreamWriter(file, true)) { 
                   stream.WriteLine(product.ToString());
            }

        }
        public void SaveAllDataIntoFile(List<ProductModel> products)
        {
            File.WriteAllText(file, string.Empty);
            foreach (ProductModel product in products) {
                SaveInFile(product);
            }
        }

      



        //   Ali,50,03055465464

        public List<ProductModel> GetProductsFromFile()
        {
            List<ProductModel> productsList = new List<ProductModel>();
            using (StreamReader stream = new StreamReader(file)) {

                string line = "";
                while((line = stream.ReadLine()) != null){

                    string[] parts = line.Split(',');
                    string productName = parts[0];
                    string desc = parts[1];
                    float purchasePrice = float.Parse(parts[2]);
                    float salePrice = float.Parse(parts[3]);
                    float discount = float.Parse(parts[4]);

                    ProductModel productModel = new ProductModel(productName, desc, purchasePrice, salePrice, discount);
                    productsList.Add(productModel);

                }
            
            }

            return productsList;
        } 


        public List<bool> QuizDobaraQuestion()
        {
            List<bool> all = new List<bool>();
            for (int i = 0; i < 100000000; i++) { 
                all.Add(false);
            }
            return all;
        }

    }
}
