﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classapp.Product
{
    internal class ProductService
    {
        private ProductRepo _repo = new ProductRepo();
        public ProductService() {

        }
        public List<ProductModel> GetAllData()
        {
            return _repo.GetProductsFromFile();
        }

        public void SaveProduct(ProductModel product)
        {
            //check if product already exists 
            _repo.SaveInFile(product);
        }

        public ProductModel SearchByName(string name)
        {
            foreach (ProductModel model in _repo.GetProductsFromFile())
            {
                if (model.GetName() == name)
                {
                    Console.WriteLine(model);
                    Console.ReadKey();
                    return model;

                }
            }
            return null;
        }

        public List<ProductModel> SearchByPriceOfProduct(float Price)
        {
            List<ProductModel> Similar = new List<ProductModel>();
            foreach (ProductModel product in _repo.GetProductsFromFile())
            {


                if (product.GetPurchasePrice() == Price)
                {

                    Console.WriteLine(product);
                    Similar.Add(product);

                }

            }
            Console.ReadKey();
            return Similar;
        }


        public bool UpdateProductPrice(string name, float SalePrice)
        {
            List<ProductModel> products = _repo.GetProductsFromFile();
            foreach (ProductModel product in products)
            {
                if (product.GetName() == name)
                {
                    product.SetSalePrice(SalePrice);
                    _repo.SaveAllDataIntoFile(products);
                    return true;
                }
            }

            return false;
        }

        public List<ProductModel> GetProductsBySaleLimit(float limit)
        {
            List<ProductModel> allProducts = _repo.GetProductsFromFile();
            List<ProductModel> selectedProducts = new List<ProductModel>();
            foreach (ProductModel product in allProducts) {

                if (product.GetSalePrice() > limit)
                {
                    selectedProducts.Add(product);
                }

            }
            return selectedProducts;
        }

        public List<ProductModel> GetFilterProductsByFirstCharacter(string condition)
        {
            List<ProductModel> allproducts = _repo.GetProductsFromFile();
            List<ProductModel> filterProducts = new List<ProductModel>();

            foreach (ProductModel product in allproducts) {

                if (product.GetName().ToLower()[0] == condition.ToLower()[0])
                {
                    filterProducts.Add(product);
                }
            }
            return filterProducts;
        }


        public List<ProductModel> SearchByKeyword(string condition)
        {
            List<ProductModel> allproducts = _repo.GetProductsFromFile();
            List<ProductModel> filterProducts = new List<ProductModel>();

            foreach (ProductModel product in allproducts)
            {

                if (product.GetName().ToLower().Contains(condition))
                {
                    filterProducts.Add(product);
                }
            }
            return filterProducts;
        }

        public bool DeleteProduct(string name)
        {
            List<ProductModel> products = _repo.GetProductsFromFile();
            int count = 0;
            foreach (ProductModel product in products)
            {
                if (product.GetName() == name)
                {
                    products.RemoveAt(count);
                    _repo.SaveAllDataIntoFile(products);
                    return true;
                }
                count++;
            }

            return false;
        }

        public List<ProductModel> SearchByRange(float Starting, float End)
        {
            List<ProductModel> Filtered = new List<ProductModel>();

            List<ProductModel> Products = _repo.GetProductsFromFile();

            foreach (ProductModel product in Products)
            {
                if (product.GetPurchasePrice() >= Starting && product.GetPurchasePrice() <= End)
                {

                    Filtered.Add(product);

                }

            }
            if (Filtered.Count > 0)
            {
                foreach (var products in Filtered)
                {
                    Console.WriteLine(products);

                }

            }
            else
            {
                Console.WriteLine("No Product Found");
            }
            Console.ReadKey();
            return Filtered;


        }


        
        public List<ProductModel> GetSubString(string substring)
        {

            List<ProductModel> Extract = new List<ProductModel>();
            foreach (ProductModel product in _repo.GetProductsFromFile())

            {
                if (product.GetName().ToLower().Contains(substring.ToLower()) || product.GetDescription().ToLower().Contains(substring.ToLower()))
                {

                    Extract.Add(product);

                }
            }

            if (Extract.Count > 0)


                foreach (var product in Extract)
                {

                    Console.WriteLine(product);


                }

            else
            {
                Console.WriteLine("No such product or product description found");
            }

            Console.ReadLine();
            return Extract;
        }

             
        


        public List<ProductModel> FindProductByDiff( float number )
        {
            List<ProductModel> difference = new List<ProductModel>();

            foreach (ProductModel product in _repo.GetProductsFromFile())
            {
                float diff = Math.Abs(product.GetSalePrice() - product.GetPurchasePrice());

                if (number == diff)
                {
                    difference.Add(product);
                }
            
            }
            if( difference.Count > 0)
            {
                foreach(var products in difference)
                {
                    Console.WriteLine(products);

                }
            }


            Console.ReadKey();
            return difference;
        }


    }
}
