﻿using Classapp.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Classapp.Product
{
    internal class ProductUI
    {

        ProductService service = new ProductService();

        OrderRepo repo = new OrderRepo();

        public void ProductDriver()
        {
            while (true) {
                Console.Clear();
                string option = ProductMenu();
                if (option == "1")
                {
                    ProductModel product = TakeInput();
                    service.SaveProduct(product);
                }
                else if (option == "2")
                {
                    UpdateProduct();
                }
                else if (option == "3") { DeleteProduct(); }
                else if (option == "4") { DisplayAll(); }
                else if (option == "5") { break; }
                else if (option == "7") {
                    TakeFilterData();
                }
                else if (option == "8")
                {
                    TakeProductSalePrice();
                }
                else if (option == "9")
                {
                    while (true)
                    {
                        Console.Clear();
                        string Opt = AdvaceSearcMenu();

                        if (Opt == "1") {

                            SearchByName();

                        }
                        if (Opt == "2") {

                            SearchByPrice();
                        }
                        if (Opt == "3")
                        {
                            SearchByRange();
                        }
                        if (Opt == "4") 
                        {
                            SearchByDiffe();
                        }
                        if (Opt == "5") {

                            break;
                        }
                        if (Opt == "6") 
                        { 
                            FindSubstring();
                        }
                        

                    }

                }
                else { Console.WriteLine("Wrong option selected"); }

            }
        }

        public void TakeProductSalePrice()
        {
            Console.WriteLine("Enter Sale Price ");
            float price = float.Parse(Console.ReadLine());
            List<ProductModel> selected = service.GetProductsBySaleLimit(price);
            if (selected.Count > 0)
            {
                DisplayByList(selected);
            }
            else
            {
                Console.WriteLine("No product found ");
                Console.ReadKey();
            }
        }

        public void SearchByPrice()
        {
            Console.WriteLine("Enter price : ");
            float Price = float.Parse(Console.ReadLine());

            service.SearchByPriceOfProduct(Price);


        }

        public void TakeFilterData()
        {
            Console.WriteLine("Enter the character you want to filter");
            string name = Console.ReadLine();
            List<ProductModel> filter = service.GetFilterProductsByFirstCharacter(name);
            if (filter.Count > 0)
            {
                DisplayByList(filter);
            }
            else
            {
                Console.WriteLine("Record not found");
                Console.ReadKey();
            }
        }

        public void DisplayByList(List<ProductModel> list)
        {
            foreach (ProductModel product in list) {
                Console.WriteLine(product.ToString());
            }
            Console.ReadKey();
        }

        public void UpdateProduct()
        {
            Console.WriteLine("Enter product name ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter product price ");
            float price = float.Parse(Console.ReadLine());

            service.UpdateProductPrice(name, price);
        }

        public void DeleteProduct()
        {
            Console.WriteLine("Enter product name ");
            string name = Console.ReadLine();

            service.DeleteProduct(name);
        }

        public void DisplayAll()
        {
            List<ProductModel> products = service.GetAllData();
            foreach (ProductModel p in products)
            {
                Console.WriteLine(p.ToString());
            }
            Console.ReadKey();
        }

        public ProductModel TakeInput()
        {
            Console.WriteLine("Enter product name ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter product description");
            string description = Console.ReadLine();
            Console.WriteLine("Enter purchase price");
            float pprice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter sale price ");
            float sprice = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter discount ");
            float discount = float.Parse(Console.ReadLine());

            ProductModel product = new ProductModel(name, description, pprice, sprice, discount);
            return product;

        }

        public string ProductMenu()
        {
            Console.WriteLine("------------------------------");
            Console.WriteLine("     Product Management       ");
            Console.WriteLine("------------------------------");
            Console.WriteLine("1 Add ");
            Console.WriteLine("2 Update");
            Console.WriteLine("3 Delete");
            Console.WriteLine("4 View All ");
            Console.WriteLine("7 Filter by First Character");
            Console.WriteLine("8 Search Products by Price Limit ");
            Console.WriteLine("9.Advance search");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("5 Back");
            Console.ForegroundColor = ConsoleColor.White;
            string option = Console.ReadLine();
            return option;
        }

        public string AdvaceSearcMenu()
        {
            Console.WriteLine("------------------------------");
            Console.WriteLine("     Advance Search Menu      ");
            Console.WriteLine("------------------------------");
            Console.WriteLine("1.Search prodcut By Name");
            Console.WriteLine("2.Search All products  by Price ");
            Console.WriteLine("3.Find product Between Given Price Range from-To ");
            Console.WriteLine("4.Find Product Whose prices fall this range of difference  ");
            Console.WriteLine("6.Find Product by SubString ");
            Console.WriteLine("enter your Option");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("5 Back");
            Console.ForegroundColor = ConsoleColor.White;
            string option = Console.ReadLine();
            return option;

        }

        public void SearchByName()
        {
            Console.WriteLine("Enter the name by which you want to search : ");
            string name = Console.ReadLine();
            service.SearchByName(name);
        }
            
        public void SearchByRange()
        {
            Console.WriteLine("Enter the starting value of range : ");
            float Starting = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Ending Value of Range");
            float End = float.Parse(Console.ReadLine());
            List<ProductModel> filtered = service.SearchByRange(Starting, End);

        }

        public void SearchByDiffe()
        {
            Console.WriteLine("Enter the difference to be search  : ");
            float number = float.Parse(Console.ReadLine());
            List<ProductModel> difference=service.FindProductByDiff(number);
        }

        public void FindSubstring()
        {
            Console.WriteLine("enter sunbstring ");
            string substring= Console.ReadLine();

            List<ProductModel> Extract = service.GetSubString(substring);
        }
    }
    

    }

//Find Products Between a Given Price Range
//o User enters a From and To value
//o Display all products whose prices fall within this range