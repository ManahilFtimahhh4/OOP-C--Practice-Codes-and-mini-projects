﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Classapp.Customer;
using Classapp.Order;
using Classapp.Product;


namespace Classapp
{
    internal class Shop
    {
        //class for the driver code

        public void Start()
        {

            while (true)
            {
                Console.Clear();
                string option = MainMenu();
                if (option == "1")
                {
                    ProductUI productUI = new ProductUI();
                    productUI.ProductDriver();
                }
                else if (option == "2") {
                    CustomerUI customerUI= new CustomerUI();
                    customerUI.CustomerDriven();
                }
                else if(option == "3") { 
                    OrderUI orderUI= new OrderUI();
                   
                }

            }
        }

        public string MainMenu()
        {
            Console.WriteLine("------------------------------");
            Console.WriteLine("             POS              ");
            Console.WriteLine("------------------------------");
            Console.WriteLine("1 to Product Management ");
            Console.WriteLine("2 to Customer Management");
            Console.WriteLine("3 Order Management");
            Console.WriteLine("4 View Order History ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("5 Exit");
            Console.ForegroundColor = ConsoleColor.White;
            string option = Console.ReadLine();
            return option;

        }

    }
}
